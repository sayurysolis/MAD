﻿namespace NominaMAD
{
    partial class P_GenerarNomina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgv_Empleados_GenerarNomina = new System.Windows.Forms.DataGridView();
            this.dtgv_DP_GenerarNomina = new System.Windows.Forms.DataGridView();
            this.btn_Regresar_GenerarNomina = new System.Windows.Forms.Button();
            this.dtgv_EmDP_GenerarNomina = new System.Windows.Forms.DataGridView();
            this.btn_Eliminar_GenerarNomina = new System.Windows.Forms.Button();
            this.btn_GenerarNominaInd_GenerarNomina = new System.Windows.Forms.Button();
            this.txt_Mes_GenerarNomina = new System.Windows.Forms.TextBox();
            this.txt_Ano_GenerarNomina = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_CierrePeriodo_GenerarNomina = new System.Windows.Forms.Button();
            this.dtgv_Matriz_GenerarNomina = new System.Windows.Forms.DataGridView();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_Empleados_GenerarNomina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_DP_GenerarNomina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_EmDP_GenerarNomina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_Matriz_GenerarNomina)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgv_Empleados_GenerarNomina
            // 
            this.dtgv_Empleados_GenerarNomina.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_Empleados_GenerarNomina.Location = new System.Drawing.Point(1019, 472);
            this.dtgv_Empleados_GenerarNomina.Name = "dtgv_Empleados_GenerarNomina";
            this.dtgv_Empleados_GenerarNomina.ReadOnly = true;
            this.dtgv_Empleados_GenerarNomina.RowHeadersWidth = 51;
            this.dtgv_Empleados_GenerarNomina.RowTemplate.Height = 24;
            this.dtgv_Empleados_GenerarNomina.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgv_Empleados_GenerarNomina.Size = new System.Drawing.Size(339, 139);
            this.dtgv_Empleados_GenerarNomina.TabIndex = 0;
            this.dtgv_Empleados_GenerarNomina.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_Empleados_GenerarNomina_CellClick);
            // 
            // dtgv_DP_GenerarNomina
            // 
            this.dtgv_DP_GenerarNomina.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_DP_GenerarNomina.Location = new System.Drawing.Point(966, 26);
            this.dtgv_DP_GenerarNomina.Name = "dtgv_DP_GenerarNomina";
            this.dtgv_DP_GenerarNomina.ReadOnly = true;
            this.dtgv_DP_GenerarNomina.RowHeadersWidth = 51;
            this.dtgv_DP_GenerarNomina.RowTemplate.Height = 24;
            this.dtgv_DP_GenerarNomina.Size = new System.Drawing.Size(279, 169);
            this.dtgv_DP_GenerarNomina.TabIndex = 1;
            this.dtgv_DP_GenerarNomina.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_DP_GenerarNomina_CellClick);
            // 
            // btn_Regresar_GenerarNomina
            // 
            this.btn_Regresar_GenerarNomina.Location = new System.Drawing.Point(778, 591);
            this.btn_Regresar_GenerarNomina.Name = "btn_Regresar_GenerarNomina";
            this.btn_Regresar_GenerarNomina.Size = new System.Drawing.Size(128, 41);
            this.btn_Regresar_GenerarNomina.TabIndex = 2;
            this.btn_Regresar_GenerarNomina.Text = "Regresar";
            this.btn_Regresar_GenerarNomina.UseVisualStyleBackColor = true;
            this.btn_Regresar_GenerarNomina.Click += new System.EventHandler(this.btn_Regresar_GenerarNomina_Click);
            // 
            // dtgv_EmDP_GenerarNomina
            // 
            this.dtgv_EmDP_GenerarNomina.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_EmDP_GenerarNomina.Location = new System.Drawing.Point(12, 472);
            this.dtgv_EmDP_GenerarNomina.Name = "dtgv_EmDP_GenerarNomina";
            this.dtgv_EmDP_GenerarNomina.ReadOnly = true;
            this.dtgv_EmDP_GenerarNomina.RowHeadersWidth = 51;
            this.dtgv_EmDP_GenerarNomina.RowTemplate.Height = 24;
            this.dtgv_EmDP_GenerarNomina.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgv_EmDP_GenerarNomina.Size = new System.Drawing.Size(492, 189);
            this.dtgv_EmDP_GenerarNomina.TabIndex = 4;
            this.dtgv_EmDP_GenerarNomina.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_EmDP_GenerarNomina_CellContentClick);
            // 
            // btn_Eliminar_GenerarNomina
            // 
            this.btn_Eliminar_GenerarNomina.Location = new System.Drawing.Point(185, 853);
            this.btn_Eliminar_GenerarNomina.Name = "btn_Eliminar_GenerarNomina";
            this.btn_Eliminar_GenerarNomina.Size = new System.Drawing.Size(126, 33);
            this.btn_Eliminar_GenerarNomina.TabIndex = 5;
            this.btn_Eliminar_GenerarNomina.Text = "Eliminar";
            this.btn_Eliminar_GenerarNomina.UseVisualStyleBackColor = true;
            this.btn_Eliminar_GenerarNomina.Click += new System.EventHandler(this.btn_Eliminar_GenerarNomina_Click);
            // 
            // btn_GenerarNominaInd_GenerarNomina
            // 
            this.btn_GenerarNominaInd_GenerarNomina.Location = new System.Drawing.Point(1007, 217);
            this.btn_GenerarNominaInd_GenerarNomina.Name = "btn_GenerarNominaInd_GenerarNomina";
            this.btn_GenerarNominaInd_GenerarNomina.Size = new System.Drawing.Size(155, 67);
            this.btn_GenerarNominaInd_GenerarNomina.TabIndex = 6;
            this.btn_GenerarNominaInd_GenerarNomina.Text = "Generar Nomina";
            this.btn_GenerarNominaInd_GenerarNomina.UseVisualStyleBackColor = true;
            this.btn_GenerarNominaInd_GenerarNomina.Click += new System.EventHandler(this.btn_GenerarNominaInd_GenerarNomina_Click);
            // 
            // txt_Mes_GenerarNomina
            // 
            this.txt_Mes_GenerarNomina.Location = new System.Drawing.Point(529, 535);
            this.txt_Mes_GenerarNomina.Name = "txt_Mes_GenerarNomina";
            this.txt_Mes_GenerarNomina.Size = new System.Drawing.Size(207, 22);
            this.txt_Mes_GenerarNomina.TabIndex = 7;
            // 
            // txt_Ano_GenerarNomina
            // 
            this.txt_Ano_GenerarNomina.Location = new System.Drawing.Point(765, 535);
            this.txt_Ano_GenerarNomina.Name = "txt_Ano_GenerarNomina";
            this.txt_Ano_GenerarNomina.Size = new System.Drawing.Size(218, 22);
            this.txt_Ano_GenerarNomina.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(703, 452);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Periodo Actual";
            // 
            // btn_CierrePeriodo_GenerarNomina
            // 
            this.btn_CierrePeriodo_GenerarNomina.Location = new System.Drawing.Point(577, 602);
            this.btn_CierrePeriodo_GenerarNomina.Name = "btn_CierrePeriodo_GenerarNomina";
            this.btn_CierrePeriodo_GenerarNomina.Size = new System.Drawing.Size(142, 25);
            this.btn_CierrePeriodo_GenerarNomina.TabIndex = 10;
            this.btn_CierrePeriodo_GenerarNomina.Text = "Cierra De Periodo";
            this.btn_CierrePeriodo_GenerarNomina.UseVisualStyleBackColor = true;
            this.btn_CierrePeriodo_GenerarNomina.Click += new System.EventHandler(this.btn_CierrePeriodo_GenerarNomina_Click);
            // 
            // dtgv_Matriz_GenerarNomina
            // 
            this.dtgv_Matriz_GenerarNomina.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_Matriz_GenerarNomina.Location = new System.Drawing.Point(12, 12);
            this.dtgv_Matriz_GenerarNomina.Name = "dtgv_Matriz_GenerarNomina";
            this.dtgv_Matriz_GenerarNomina.RowHeadersWidth = 51;
            this.dtgv_Matriz_GenerarNomina.RowTemplate.Height = 24;
            this.dtgv_Matriz_GenerarNomina.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgv_Matriz_GenerarNomina.Size = new System.Drawing.Size(915, 365);
            this.dtgv_Matriz_GenerarNomina.TabIndex = 11;
            this.dtgv_Matriz_GenerarNomina.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_Matriz_GenerarNomina_CellContentClick);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(12, 430);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(95, 20);
            this.checkBox1.TabIndex = 12;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // P_GenerarNomina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 669);
            this.ControlBox = false;
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dtgv_Matriz_GenerarNomina);
            this.Controls.Add(this.btn_CierrePeriodo_GenerarNomina);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Ano_GenerarNomina);
            this.Controls.Add(this.txt_Mes_GenerarNomina);
            this.Controls.Add(this.btn_GenerarNominaInd_GenerarNomina);
            this.Controls.Add(this.btn_Eliminar_GenerarNomina);
            this.Controls.Add(this.dtgv_EmDP_GenerarNomina);
            this.Controls.Add(this.btn_Regresar_GenerarNomina);
            this.Controls.Add(this.dtgv_DP_GenerarNomina);
            this.Controls.Add(this.dtgv_Empleados_GenerarNomina);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_GenerarNomina";
            this.Text = "Generar Nomina";
            this.Load += new System.EventHandler(this.P_GenerarNomina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_Empleados_GenerarNomina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_DP_GenerarNomina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_EmDP_GenerarNomina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_Matriz_GenerarNomina)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgv_Empleados_GenerarNomina;
        private System.Windows.Forms.DataGridView dtgv_DP_GenerarNomina;
        private System.Windows.Forms.Button btn_Regresar_GenerarNomina;
        private System.Windows.Forms.DataGridView dtgv_EmDP_GenerarNomina;
        private System.Windows.Forms.Button btn_Eliminar_GenerarNomina;
        private System.Windows.Forms.Button btn_GenerarNominaInd_GenerarNomina;
        private System.Windows.Forms.TextBox txt_Mes_GenerarNomina;
        private System.Windows.Forms.TextBox txt_Ano_GenerarNomina;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_CierrePeriodo_GenerarNomina;
        private System.Windows.Forms.DataGridView dtgv_Matriz_GenerarNomina;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}