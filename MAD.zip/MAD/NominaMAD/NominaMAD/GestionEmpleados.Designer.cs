﻿namespace NominaMAD
{
    partial class P_GestionEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Regresar_GestionEmpleados = new System.Windows.Forms.Button();
            this.btn_Modificar_GestionEmpleados = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_Telefono_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dateTimer_FechaIngreEmpr_GestionEmpleados = new System.Windows.Forms.DateTimePicker();
            this.CmBox_Puesto_GestionEmpleados = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Cmbox_Departamento_GestionEmpleados = new System.Windows.Forms.ComboBox();
            this.txt_Email_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_NumCuenta_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_Banco_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_DomCompleto_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_RFC_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_NSS_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.LABEL_NSS_GestionEmpleados = new System.Windows.Forms.Label();
            this.txt_Curp_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimer_FechaNacim_GestionEmpleados = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_ApellMaterno_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_ApellPaterno_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Nombres_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_NumEmplea_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Agregar_GestionEmpleados = new System.Windows.Forms.Button();
            this.btn_Buscar_GestionEmpleados = new System.Windows.Forms.Button();
            this.btn_Eliminar_GestionEmpleados = new System.Windows.Forms.Button();
            this.btn_AceptarMOD_GestionEmpleados = new System.Windows.Forms.Button();
            this.btn_CancelarMOD_GestionEmpleados = new System.Windows.Forms.Button();
            this.txt_MosNumEmplea_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_AgregarAceptar_GestionEmpleados = new System.Windows.Forms.Button();
            this.btn_AgregarCancelar_GestionEmpleados = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_SalarioDiario_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.txt_SalarioDIntegrado_GestionEmpleados = new System.Windows.Forms.TextBox();
            this.CmBox_Estatus_GestionEmpleados = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.CmBox_Turno_GestionEmpleados = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_Regresar_GestionEmpleados
            // 
            this.btn_Regresar_GestionEmpleados.Location = new System.Drawing.Point(357, 587);
            this.btn_Regresar_GestionEmpleados.Name = "btn_Regresar_GestionEmpleados";
            this.btn_Regresar_GestionEmpleados.Size = new System.Drawing.Size(124, 44);
            this.btn_Regresar_GestionEmpleados.TabIndex = 77;
            this.btn_Regresar_GestionEmpleados.Text = "Regresar";
            this.btn_Regresar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_Regresar_GestionEmpleados.Click += new System.EventHandler(this.btn_Regresar_GestionEmpleados_Click);
            // 
            // btn_Modificar_GestionEmpleados
            // 
            this.btn_Modificar_GestionEmpleados.Location = new System.Drawing.Point(11, 494);
            this.btn_Modificar_GestionEmpleados.Name = "btn_Modificar_GestionEmpleados";
            this.btn_Modificar_GestionEmpleados.Size = new System.Drawing.Size(104, 42);
            this.btn_Modificar_GestionEmpleados.TabIndex = 75;
            this.btn_Modificar_GestionEmpleados.Text = "Modificar";
            this.btn_Modificar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_Modificar_GestionEmpleados.Click += new System.EventHandler(this.btn_Modificar_GestionEmpleados_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(530, 478);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 20);
            this.label17.TabIndex = 74;
            this.label17.Text = "Telefono:";
            // 
            // txt_Telefono_GestionEmpleados
            // 
            this.txt_Telefono_GestionEmpleados.Location = new System.Drawing.Point(640, 476);
            this.txt_Telefono_GestionEmpleados.Name = "txt_Telefono_GestionEmpleados";
            this.txt_Telefono_GestionEmpleados.Size = new System.Drawing.Size(127, 22);
            this.txt_Telefono_GestionEmpleados.TabIndex = 73;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(530, 433);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 20);
            this.label16.TabIndex = 72;
            this.label16.Text = "Email:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(516, 524);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(277, 20);
            this.label15.TabIndex = 71;
            this.label15.Text = "Fecha de Ingreso a la Empresa:";
            // 
            // dateTimer_FechaIngreEmpr_GestionEmpleados
            // 
            this.dateTimer_FechaIngreEmpr_GestionEmpleados.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimer_FechaIngreEmpr_GestionEmpleados.Location = new System.Drawing.Point(817, 524);
            this.dateTimer_FechaIngreEmpr_GestionEmpleados.Name = "dateTimer_FechaIngreEmpr_GestionEmpleados";
            this.dateTimer_FechaIngreEmpr_GestionEmpleados.Size = new System.Drawing.Size(119, 22);
            this.dateTimer_FechaIngreEmpr_GestionEmpleados.TabIndex = 70;
            // 
            // CmBox_Puesto_GestionEmpleados
            // 
            this.CmBox_Puesto_GestionEmpleados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBox_Puesto_GestionEmpleados.FormattingEnabled = true;
            this.CmBox_Puesto_GestionEmpleados.Location = new System.Drawing.Point(121, 297);
            this.CmBox_Puesto_GestionEmpleados.Name = "CmBox_Puesto_GestionEmpleados";
            this.CmBox_Puesto_GestionEmpleados.Size = new System.Drawing.Size(210, 24);
            this.CmBox_Puesto_GestionEmpleados.TabIndex = 69;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(21, 297);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 20);
            this.label14.TabIndex = 68;
            this.label14.Text = "Puesto: ";
            // 
            // Cmbox_Departamento_GestionEmpleados
            // 
            this.Cmbox_Departamento_GestionEmpleados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cmbox_Departamento_GestionEmpleados.FormattingEnabled = true;
            this.Cmbox_Departamento_GestionEmpleados.Location = new System.Drawing.Point(185, 247);
            this.Cmbox_Departamento_GestionEmpleados.Name = "Cmbox_Departamento_GestionEmpleados";
            this.Cmbox_Departamento_GestionEmpleados.Size = new System.Drawing.Size(186, 24);
            this.Cmbox_Departamento_GestionEmpleados.TabIndex = 67;
            this.Cmbox_Departamento_GestionEmpleados.SelectedIndexChanged += new System.EventHandler(this.Cmbox_Departamento_GestionEmpleados_SelectedIndexChanged_1);
            // 
            // txt_Email_GestionEmpleados
            // 
            this.txt_Email_GestionEmpleados.Location = new System.Drawing.Point(598, 433);
            this.txt_Email_GestionEmpleados.Name = "txt_Email_GestionEmpleados";
            this.txt_Email_GestionEmpleados.Size = new System.Drawing.Size(246, 22);
            this.txt_Email_GestionEmpleados.TabIndex = 66;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 247);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 20);
            this.label13.TabIndex = 65;
            this.label13.Text = "Departamento:";
            // 
            // txt_NumCuenta_GestionEmpleados
            // 
            this.txt_NumCuenta_GestionEmpleados.Location = new System.Drawing.Point(720, 222);
            this.txt_NumCuenta_GestionEmpleados.Name = "txt_NumCuenta_GestionEmpleados";
            this.txt_NumCuenta_GestionEmpleados.Size = new System.Drawing.Size(170, 22);
            this.txt_NumCuenta_GestionEmpleados.TabIndex = 64;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(519, 222);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 20);
            this.label12.TabIndex = 63;
            this.label12.Text = "Numero de Cuenta:";
            // 
            // txt_Banco_GestionEmpleados
            // 
            this.txt_Banco_GestionEmpleados.Location = new System.Drawing.Point(601, 180);
            this.txt_Banco_GestionEmpleados.Name = "txt_Banco_GestionEmpleados";
            this.txt_Banco_GestionEmpleados.Size = new System.Drawing.Size(231, 22);
            this.txt_Banco_GestionEmpleados.TabIndex = 62;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(518, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 20);
            this.label11.TabIndex = 61;
            this.label11.Text = "Banco:";
            // 
            // txt_DomCompleto_GestionEmpleados
            // 
            this.txt_DomCompleto_GestionEmpleados.Location = new System.Drawing.Point(719, 141);
            this.txt_DomCompleto_GestionEmpleados.Name = "txt_DomCompleto_GestionEmpleados";
            this.txt_DomCompleto_GestionEmpleados.Size = new System.Drawing.Size(299, 22);
            this.txt_DomCompleto_GestionEmpleados.TabIndex = 60;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(514, 141);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(179, 20);
            this.label10.TabIndex = 59;
            this.label10.Text = "Domicilio Completo:";
            // 
            // txt_RFC_GestionEmpleados
            // 
            this.txt_RFC_GestionEmpleados.Location = new System.Drawing.Point(585, 98);
            this.txt_RFC_GestionEmpleados.Name = "txt_RFC_GestionEmpleados";
            this.txt_RFC_GestionEmpleados.Size = new System.Drawing.Size(163, 22);
            this.txt_RFC_GestionEmpleados.TabIndex = 58;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(516, 100);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 20);
            this.label9.TabIndex = 57;
            this.label9.Text = "RFC:";
            // 
            // txt_NSS_GestionEmpleados
            // 
            this.txt_NSS_GestionEmpleados.Location = new System.Drawing.Point(837, 62);
            this.txt_NSS_GestionEmpleados.Name = "txt_NSS_GestionEmpleados";
            this.txt_NSS_GestionEmpleados.Size = new System.Drawing.Size(189, 22);
            this.txt_NSS_GestionEmpleados.TabIndex = 56;
            // 
            // LABEL_NSS_GestionEmpleados
            // 
            this.LABEL_NSS_GestionEmpleados.AutoSize = true;
            this.LABEL_NSS_GestionEmpleados.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LABEL_NSS_GestionEmpleados.Location = new System.Drawing.Point(512, 62);
            this.LABEL_NSS_GestionEmpleados.Name = "LABEL_NSS_GestionEmpleados";
            this.LABEL_NSS_GestionEmpleados.Size = new System.Drawing.Size(280, 20);
            this.LABEL_NSS_GestionEmpleados.TabIndex = 55;
            this.LABEL_NSS_GestionEmpleados.Text = "Numero de Seguro Social(NSS):";
            // 
            // txt_Curp_GestionEmpleados
            // 
            this.txt_Curp_GestionEmpleados.Location = new System.Drawing.Point(68, 401);
            this.txt_Curp_GestionEmpleados.Name = "txt_Curp_GestionEmpleados";
            this.txt_Curp_GestionEmpleados.Size = new System.Drawing.Size(212, 22);
            this.txt_Curp_GestionEmpleados.TabIndex = 54;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 20);
            this.label8.TabIndex = 53;
            this.label8.Text = "Curp:";
            // 
            // dateTimer_FechaNacim_GestionEmpleados
            // 
            this.dateTimer_FechaNacim_GestionEmpleados.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimer_FechaNacim_GestionEmpleados.Location = new System.Drawing.Point(243, 350);
            this.dateTimer_FechaNacim_GestionEmpleados.Name = "dateTimer_FechaNacim_GestionEmpleados";
            this.dateTimer_FechaNacim_GestionEmpleados.Size = new System.Drawing.Size(120, 22);
            this.dateTimer_FechaNacim_GestionEmpleados.TabIndex = 52;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(15, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(192, 20);
            this.label7.TabIndex = 51;
            this.label7.Text = "Fecha de Nacimiento:";
            // 
            // txt_ApellMaterno_GestionEmpleados
            // 
            this.txt_ApellMaterno_GestionEmpleados.Location = new System.Drawing.Point(209, 198);
            this.txt_ApellMaterno_GestionEmpleados.Name = "txt_ApellMaterno_GestionEmpleados";
            this.txt_ApellMaterno_GestionEmpleados.Size = new System.Drawing.Size(198, 22);
            this.txt_ApellMaterno_GestionEmpleados.TabIndex = 50;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 20);
            this.label6.TabIndex = 49;
            this.label6.Text = "Apellido Materno:";
            // 
            // txt_ApellPaterno_GestionEmpleados
            // 
            this.txt_ApellPaterno_GestionEmpleados.Location = new System.Drawing.Point(185, 147);
            this.txt_ApellPaterno_GestionEmpleados.Name = "txt_ApellPaterno_GestionEmpleados";
            this.txt_ApellPaterno_GestionEmpleados.Size = new System.Drawing.Size(217, 22);
            this.txt_ApellPaterno_GestionEmpleados.TabIndex = 48;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 20);
            this.label5.TabIndex = 47;
            this.label5.Text = "Apellido Paterno:";
            // 
            // txt_Nombres_GestionEmpleados
            // 
            this.txt_Nombres_GestionEmpleados.Location = new System.Drawing.Point(125, 99);
            this.txt_Nombres_GestionEmpleados.Name = "txt_Nombres_GestionEmpleados";
            this.txt_Nombres_GestionEmpleados.Size = new System.Drawing.Size(259, 22);
            this.txt_Nombres_GestionEmpleados.TabIndex = 46;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 20);
            this.label4.TabIndex = 45;
            this.label4.Text = "Nombre(s):";
            // 
            // txt_NumEmplea_GestionEmpleados
            // 
            this.txt_NumEmplea_GestionEmpleados.Location = new System.Drawing.Point(324, 14);
            this.txt_NumEmplea_GestionEmpleados.Name = "txt_NumEmplea_GestionEmpleados";
            this.txt_NumEmplea_GestionEmpleados.Size = new System.Drawing.Size(196, 22);
            this.txt_NumEmplea_GestionEmpleados.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(299, 20);
            this.label2.TabIndex = 41;
            this.label2.Text = "Buscar por Numero de Empleado: ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btn_Agregar_GestionEmpleados
            // 
            this.btn_Agregar_GestionEmpleados.Location = new System.Drawing.Point(11, 444);
            this.btn_Agregar_GestionEmpleados.Name = "btn_Agregar_GestionEmpleados";
            this.btn_Agregar_GestionEmpleados.Size = new System.Drawing.Size(104, 44);
            this.btn_Agregar_GestionEmpleados.TabIndex = 78;
            this.btn_Agregar_GestionEmpleados.Text = "Agregar";
            this.btn_Agregar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_Agregar_GestionEmpleados.Click += new System.EventHandler(this.btn_Agregar_GestionEmpleados_Click);
            // 
            // btn_Buscar_GestionEmpleados
            // 
            this.btn_Buscar_GestionEmpleados.Location = new System.Drawing.Point(549, 12);
            this.btn_Buscar_GestionEmpleados.Name = "btn_Buscar_GestionEmpleados";
            this.btn_Buscar_GestionEmpleados.Size = new System.Drawing.Size(96, 24);
            this.btn_Buscar_GestionEmpleados.TabIndex = 79;
            this.btn_Buscar_GestionEmpleados.Text = "Buscar";
            this.btn_Buscar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_Buscar_GestionEmpleados.Click += new System.EventHandler(this.btn_Buscar_GestionEmpleados_Click);
            // 
            // btn_Eliminar_GestionEmpleados
            // 
            this.btn_Eliminar_GestionEmpleados.Location = new System.Drawing.Point(11, 542);
            this.btn_Eliminar_GestionEmpleados.Name = "btn_Eliminar_GestionEmpleados";
            this.btn_Eliminar_GestionEmpleados.Size = new System.Drawing.Size(101, 45);
            this.btn_Eliminar_GestionEmpleados.TabIndex = 80;
            this.btn_Eliminar_GestionEmpleados.Text = "Eliminar";
            this.btn_Eliminar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_Eliminar_GestionEmpleados.Click += new System.EventHandler(this.btn_Eliminar_GestionEmpleados_Click);
            // 
            // btn_AceptarMOD_GestionEmpleados
            // 
            this.btn_AceptarMOD_GestionEmpleados.Location = new System.Drawing.Point(147, 527);
            this.btn_AceptarMOD_GestionEmpleados.Name = "btn_AceptarMOD_GestionEmpleados";
            this.btn_AceptarMOD_GestionEmpleados.Size = new System.Drawing.Size(184, 32);
            this.btn_AceptarMOD_GestionEmpleados.TabIndex = 81;
            this.btn_AceptarMOD_GestionEmpleados.Text = "Aceptar Modificacion ";
            this.btn_AceptarMOD_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_AceptarMOD_GestionEmpleados.Click += new System.EventHandler(this.btn_AceptarMOD_GestionEmpleados_Click);
            // 
            // btn_CancelarMOD_GestionEmpleados
            // 
            this.btn_CancelarMOD_GestionEmpleados.Location = new System.Drawing.Point(147, 576);
            this.btn_CancelarMOD_GestionEmpleados.Name = "btn_CancelarMOD_GestionEmpleados";
            this.btn_CancelarMOD_GestionEmpleados.Size = new System.Drawing.Size(184, 32);
            this.btn_CancelarMOD_GestionEmpleados.TabIndex = 82;
            this.btn_CancelarMOD_GestionEmpleados.Text = "Cancelar Modificacion ";
            this.btn_CancelarMOD_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_CancelarMOD_GestionEmpleados.Click += new System.EventHandler(this.btn_CancelarMOD_GestionEmpleados_Click);
            // 
            // txt_MosNumEmplea_GestionEmpleados
            // 
            this.txt_MosNumEmplea_GestionEmpleados.Location = new System.Drawing.Point(209, 58);
            this.txt_MosNumEmplea_GestionEmpleados.Name = "txt_MosNumEmplea_GestionEmpleados";
            this.txt_MosNumEmplea_GestionEmpleados.Size = new System.Drawing.Size(196, 22);
            this.txt_MosNumEmplea_GestionEmpleados.TabIndex = 84;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 20);
            this.label1.TabIndex = 83;
            this.label1.Text = "Numero de Empleado: ";
            // 
            // btn_AgregarAceptar_GestionEmpleados
            // 
            this.btn_AgregarAceptar_GestionEmpleados.Location = new System.Drawing.Point(157, 444);
            this.btn_AgregarAceptar_GestionEmpleados.Name = "btn_AgregarAceptar_GestionEmpleados";
            this.btn_AgregarAceptar_GestionEmpleados.Size = new System.Drawing.Size(106, 31);
            this.btn_AgregarAceptar_GestionEmpleados.TabIndex = 85;
            this.btn_AgregarAceptar_GestionEmpleados.Text = "Aceptar";
            this.btn_AgregarAceptar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_AgregarAceptar_GestionEmpleados.Click += new System.EventHandler(this.btn_AgregarAceptar_GestionEmpleados_Click);
            // 
            // btn_AgregarCancelar_GestionEmpleados
            // 
            this.btn_AgregarCancelar_GestionEmpleados.Location = new System.Drawing.Point(157, 490);
            this.btn_AgregarCancelar_GestionEmpleados.Name = "btn_AgregarCancelar_GestionEmpleados";
            this.btn_AgregarCancelar_GestionEmpleados.Size = new System.Drawing.Size(106, 31);
            this.btn_AgregarCancelar_GestionEmpleados.TabIndex = 86;
            this.btn_AgregarCancelar_GestionEmpleados.Text = "Cancelar";
            this.btn_AgregarCancelar_GestionEmpleados.UseVisualStyleBackColor = true;
            this.btn_AgregarCancelar_GestionEmpleados.Click += new System.EventHandler(this.btn_AgregarCancelar_GestionEmpleados_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(521, 354);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 20);
            this.label18.TabIndex = 87;
            this.label18.Text = "Estatus:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(518, 311);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(215, 20);
            this.label19.TabIndex = 88;
            this.label19.Text = "Salario Diario Integrado:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(519, 264);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(131, 20);
            this.label20.TabIndex = 89;
            this.label20.Text = "Salario Diario:";
            // 
            // txt_SalarioDiario_GestionEmpleados
            // 
            this.txt_SalarioDiario_GestionEmpleados.Location = new System.Drawing.Point(651, 264);
            this.txt_SalarioDiario_GestionEmpleados.Name = "txt_SalarioDiario_GestionEmpleados";
            this.txt_SalarioDiario_GestionEmpleados.Size = new System.Drawing.Size(177, 22);
            this.txt_SalarioDiario_GestionEmpleados.TabIndex = 90;
            // 
            // txt_SalarioDIntegrado_GestionEmpleados
            // 
            this.txt_SalarioDIntegrado_GestionEmpleados.Location = new System.Drawing.Point(759, 311);
            this.txt_SalarioDIntegrado_GestionEmpleados.Name = "txt_SalarioDIntegrado_GestionEmpleados";
            this.txt_SalarioDIntegrado_GestionEmpleados.Size = new System.Drawing.Size(177, 22);
            this.txt_SalarioDIntegrado_GestionEmpleados.TabIndex = 91;
            // 
            // CmBox_Estatus_GestionEmpleados
            // 
            this.CmBox_Estatus_GestionEmpleados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBox_Estatus_GestionEmpleados.FormattingEnabled = true;
            this.CmBox_Estatus_GestionEmpleados.Location = new System.Drawing.Point(604, 353);
            this.CmBox_Estatus_GestionEmpleados.Name = "CmBox_Estatus_GestionEmpleados";
            this.CmBox_Estatus_GestionEmpleados.Size = new System.Drawing.Size(151, 24);
            this.CmBox_Estatus_GestionEmpleados.TabIndex = 92;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(521, 392);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 20);
            this.label21.TabIndex = 93;
            this.label21.Text = "Turno:";
            // 
            // CmBox_Turno_GestionEmpleados
            // 
            this.CmBox_Turno_GestionEmpleados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBox_Turno_GestionEmpleados.FormattingEnabled = true;
            this.CmBox_Turno_GestionEmpleados.Location = new System.Drawing.Point(598, 392);
            this.CmBox_Turno_GestionEmpleados.Name = "CmBox_Turno_GestionEmpleados";
            this.CmBox_Turno_GestionEmpleados.Size = new System.Drawing.Size(139, 24);
            this.CmBox_Turno_GestionEmpleados.TabIndex = 94;
            // 
            // P_GestionEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 643);
            this.ControlBox = false;
            this.Controls.Add(this.CmBox_Turno_GestionEmpleados);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.CmBox_Estatus_GestionEmpleados);
            this.Controls.Add(this.txt_SalarioDIntegrado_GestionEmpleados);
            this.Controls.Add(this.txt_SalarioDiario_GestionEmpleados);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btn_AgregarCancelar_GestionEmpleados);
            this.Controls.Add(this.btn_AgregarAceptar_GestionEmpleados);
            this.Controls.Add(this.txt_MosNumEmplea_GestionEmpleados);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_CancelarMOD_GestionEmpleados);
            this.Controls.Add(this.btn_AceptarMOD_GestionEmpleados);
            this.Controls.Add(this.btn_Eliminar_GestionEmpleados);
            this.Controls.Add(this.btn_Buscar_GestionEmpleados);
            this.Controls.Add(this.btn_Agregar_GestionEmpleados);
            this.Controls.Add(this.btn_Regresar_GestionEmpleados);
            this.Controls.Add(this.btn_Modificar_GestionEmpleados);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txt_Telefono_GestionEmpleados);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dateTimer_FechaIngreEmpr_GestionEmpleados);
            this.Controls.Add(this.CmBox_Puesto_GestionEmpleados);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.Cmbox_Departamento_GestionEmpleados);
            this.Controls.Add(this.txt_Email_GestionEmpleados);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_NumCuenta_GestionEmpleados);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_Banco_GestionEmpleados);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_DomCompleto_GestionEmpleados);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_RFC_GestionEmpleados);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_NSS_GestionEmpleados);
            this.Controls.Add(this.LABEL_NSS_GestionEmpleados);
            this.Controls.Add(this.txt_Curp_GestionEmpleados);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dateTimer_FechaNacim_GestionEmpleados);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_ApellMaterno_GestionEmpleados);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_ApellPaterno_GestionEmpleados);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_Nombres_GestionEmpleados);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_NumEmplea_GestionEmpleados);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_GestionEmpleados";
            this.Text = "Gestion de Empleados ";
            this.Load += new System.EventHandler(this.P_GestionEmpleados_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Regresar_GestionEmpleados;
        private System.Windows.Forms.Button btn_Modificar_GestionEmpleados;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_Telefono_GestionEmpleados;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dateTimer_FechaIngreEmpr_GestionEmpleados;
        private System.Windows.Forms.ComboBox CmBox_Puesto_GestionEmpleados;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox Cmbox_Departamento_GestionEmpleados;
        private System.Windows.Forms.TextBox txt_Email_GestionEmpleados;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_NumCuenta_GestionEmpleados;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_Banco_GestionEmpleados;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_DomCompleto_GestionEmpleados;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_RFC_GestionEmpleados;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_NSS_GestionEmpleados;
        private System.Windows.Forms.Label LABEL_NSS_GestionEmpleados;
        private System.Windows.Forms.TextBox txt_Curp_GestionEmpleados;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dateTimer_FechaNacim_GestionEmpleados;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_ApellMaterno_GestionEmpleados;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_ApellPaterno_GestionEmpleados;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Nombres_GestionEmpleados;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_NumEmplea_GestionEmpleados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Agregar_GestionEmpleados;
        private System.Windows.Forms.Button btn_Buscar_GestionEmpleados;
        private System.Windows.Forms.Button btn_Eliminar_GestionEmpleados;
        private System.Windows.Forms.Button btn_AceptarMOD_GestionEmpleados;
        private System.Windows.Forms.Button btn_CancelarMOD_GestionEmpleados;
        private System.Windows.Forms.TextBox txt_MosNumEmplea_GestionEmpleados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_AgregarAceptar_GestionEmpleados;
        private System.Windows.Forms.Button btn_AgregarCancelar_GestionEmpleados;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_SalarioDiario_GestionEmpleados;
        private System.Windows.Forms.TextBox txt_SalarioDIntegrado_GestionEmpleados;
        private System.Windows.Forms.ComboBox CmBox_Estatus_GestionEmpleados;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox CmBox_Turno_GestionEmpleados;
    }
}