﻿namespace NominaMAD
{
    partial class P_ReciboEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Buscar_RecPEmpleado = new System.Windows.Forms.Button();
            this.txt_NumEmpleado_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Ano_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.combo_Mes = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Imprimir_RecPEmpleado = new System.Windows.Forms.Button();
            this.txt_Nombre_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NumEmpleadoMostrar_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_RFC_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Curp_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Departamento_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_Puesto_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_Banco_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_NumCuenta_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_DiasTrabajados_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_TOTPercepciones_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_TOTDeducciones_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_Neto_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_IMSS_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.btn_Regresar_RecEmpleado = new System.Windows.Forms.Button();
            this.txt_Bruto_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_SalarioDiario_RecPEmpleado = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Buscar_RecPEmpleado
            // 
            this.btn_Buscar_RecPEmpleado.Location = new System.Drawing.Point(381, 41);
            this.btn_Buscar_RecPEmpleado.Name = "btn_Buscar_RecPEmpleado";
            this.btn_Buscar_RecPEmpleado.Size = new System.Drawing.Size(104, 30);
            this.btn_Buscar_RecPEmpleado.TabIndex = 111;
            this.btn_Buscar_RecPEmpleado.Text = "Buscar";
            this.btn_Buscar_RecPEmpleado.UseVisualStyleBackColor = true;
            this.btn_Buscar_RecPEmpleado.Click += new System.EventHandler(this.btn_Buscar_RecPEmpleado_Click);
            // 
            // txt_NumEmpleado_RecPEmpleado
            // 
            this.txt_NumEmpleado_RecPEmpleado.Location = new System.Drawing.Point(256, 12);
            this.txt_NumEmpleado_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NumEmpleado_RecPEmpleado.Name = "txt_NumEmpleado_RecPEmpleado";
            this.txt_NumEmpleado_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_NumEmpleado_RecPEmpleado.TabIndex = 107;
            this.txt_NumEmpleado_RecPEmpleado.TextChanged += new System.EventHandler(this.txt_NumEmpleado_RecPEmpleado_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 12);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 20);
            this.label2.TabIndex = 110;
            this.label2.Text = "Número de empleado:";
            // 
            // txt_Ano_RecPEmpleado
            // 
            this.txt_Ano_RecPEmpleado.Location = new System.Drawing.Point(255, 46);
            this.txt_Ano_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Ano_RecPEmpleado.MaxLength = 4;
            this.txt_Ano_RecPEmpleado.Name = "txt_Ano_RecPEmpleado";
            this.txt_Ano_RecPEmpleado.Size = new System.Drawing.Size(103, 22);
            this.txt_Ano_RecPEmpleado.TabIndex = 106;
            this.txt_Ano_RecPEmpleado.TextChanged += new System.EventHandler(this.txt_Ano_RecPEmpleado_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(197, 51);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 20);
            this.label10.TabIndex = 109;
            this.label10.Text = "Año:";
            // 
            // combo_Mes
            // 
            this.combo_Mes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Mes.FormattingEnabled = true;
            this.combo_Mes.Location = new System.Drawing.Point(75, 45);
            this.combo_Mes.Margin = new System.Windows.Forms.Padding(4);
            this.combo_Mes.Name = "combo_Mes";
            this.combo_Mes.Size = new System.Drawing.Size(93, 24);
            this.combo_Mes.TabIndex = 105;
            this.combo_Mes.SelectedIndexChanged += new System.EventHandler(this.combo_Mes_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 51);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 20);
            this.label9.TabIndex = 108;
            this.label9.Text = "Mes:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 112;
            // 
            // btn_Imprimir_RecPEmpleado
            // 
            this.btn_Imprimir_RecPEmpleado.Location = new System.Drawing.Point(202, 509);
            this.btn_Imprimir_RecPEmpleado.Name = "btn_Imprimir_RecPEmpleado";
            this.btn_Imprimir_RecPEmpleado.Size = new System.Drawing.Size(125, 32);
            this.btn_Imprimir_RecPEmpleado.TabIndex = 113;
            this.btn_Imprimir_RecPEmpleado.Text = "Imprimir";
            this.btn_Imprimir_RecPEmpleado.UseVisualStyleBackColor = true;
            this.btn_Imprimir_RecPEmpleado.Click += new System.EventHandler(this.btn_Imprimir_RecPEmpleado_Click);
            // 
            // txt_Nombre_RecPEmpleado
            // 
            this.txt_Nombre_RecPEmpleado.Location = new System.Drawing.Point(94, 97);
            this.txt_Nombre_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nombre_RecPEmpleado.Name = "txt_Nombre_RecPEmpleado";
            this.txt_Nombre_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Nombre_RecPEmpleado.TabIndex = 114;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 99);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 20);
            this.label3.TabIndex = 115;
            this.label3.Text = "Nombre:";
            // 
            // txt_NumEmpleadoMostrar_RecPEmpleado
            // 
            this.txt_NumEmpleadoMostrar_RecPEmpleado.Location = new System.Drawing.Point(205, 134);
            this.txt_NumEmpleadoMostrar_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NumEmpleadoMostrar_RecPEmpleado.Name = "txt_NumEmpleadoMostrar_RecPEmpleado";
            this.txt_NumEmpleadoMostrar_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_NumEmpleadoMostrar_RecPEmpleado.TabIndex = 116;
            this.txt_NumEmpleadoMostrar_RecPEmpleado.TextChanged += new System.EventHandler(this.txt_NumEmpleadoMostrar_RecPEmpleado_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 134);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 20);
            this.label4.TabIndex = 117;
            this.label4.Text = "Número de empleado:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txt_RFC_RecPEmpleado
            // 
            this.txt_RFC_RecPEmpleado.Location = new System.Drawing.Point(79, 234);
            this.txt_RFC_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_RFC_RecPEmpleado.Name = "txt_RFC_RecPEmpleado";
            this.txt_RFC_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_RFC_RecPEmpleado.TabIndex = 118;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 234);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 119;
            this.label5.Text = "RFC:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 197);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 20);
            this.label6.TabIndex = 121;
            this.label6.Text = "IMSS:";
            // 
            // txt_Curp_RecPEmpleado
            // 
            this.txt_Curp_RecPEmpleado.Location = new System.Drawing.Point(68, 167);
            this.txt_Curp_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Curp_RecPEmpleado.Name = "txt_Curp_RecPEmpleado";
            this.txt_Curp_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Curp_RecPEmpleado.TabIndex = 122;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 167);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 20);
            this.label7.TabIndex = 123;
            this.label7.Text = "Curp:";
            // 
            // txt_Departamento_RecPEmpleado
            // 
            this.txt_Departamento_RecPEmpleado.Location = new System.Drawing.Point(147, 362);
            this.txt_Departamento_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Departamento_RecPEmpleado.Name = "txt_Departamento_RecPEmpleado";
            this.txt_Departamento_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Departamento_RecPEmpleado.TabIndex = 126;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(5, 362);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 20);
            this.label11.TabIndex = 127;
            this.label11.Text = "Departamento:";
            // 
            // txt_Puesto_RecPEmpleado
            // 
            this.txt_Puesto_RecPEmpleado.Location = new System.Drawing.Point(94, 318);
            this.txt_Puesto_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Puesto_RecPEmpleado.Name = "txt_Puesto_RecPEmpleado";
            this.txt_Puesto_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Puesto_RecPEmpleado.TabIndex = 128;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(16, 318);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 20);
            this.label12.TabIndex = 129;
            this.label12.Text = "Puesto:";
            // 
            // txt_Banco_RecPEmpleado
            // 
            this.txt_Banco_RecPEmpleado.Location = new System.Drawing.Point(481, 171);
            this.txt_Banco_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Banco_RecPEmpleado.Name = "txt_Banco_RecPEmpleado";
            this.txt_Banco_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Banco_RecPEmpleado.TabIndex = 130;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(408, 173);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 20);
            this.label13.TabIndex = 131;
            this.label13.Text = "Banco:";
            // 
            // txt_NumCuenta_RecPEmpleado
            // 
            this.txt_NumCuenta_RecPEmpleado.Location = new System.Drawing.Point(545, 211);
            this.txt_NumCuenta_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NumCuenta_RecPEmpleado.Name = "txt_NumCuenta_RecPEmpleado";
            this.txt_NumCuenta_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_NumCuenta_RecPEmpleado.TabIndex = 132;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(354, 211);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(175, 20);
            this.label14.TabIndex = 133;
            this.label14.Text = "Numero De Cuenta:";
            // 
            // txt_DiasTrabajados_RecPEmpleado
            // 
            this.txt_DiasTrabajados_RecPEmpleado.Location = new System.Drawing.Point(163, 277);
            this.txt_DiasTrabajados_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_DiasTrabajados_RecPEmpleado.Name = "txt_DiasTrabajados_RecPEmpleado";
            this.txt_DiasTrabajados_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_DiasTrabajados_RecPEmpleado.TabIndex = 134;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(2, 277);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(153, 20);
            this.label15.TabIndex = 135;
            this.label15.Text = "Dias Trabajados:";
            // 
            // txt_TOTPercepciones_RecPEmpleado
            // 
            this.txt_TOTPercepciones_RecPEmpleado.Location = new System.Drawing.Point(202, 414);
            this.txt_TOTPercepciones_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_TOTPercepciones_RecPEmpleado.Name = "txt_TOTPercepciones_RecPEmpleado";
            this.txt_TOTPercepciones_RecPEmpleado.Size = new System.Drawing.Size(139, 22);
            this.txt_TOTPercepciones_RecPEmpleado.TabIndex = 136;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(11, 414);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(177, 20);
            this.label16.TabIndex = 137;
            this.label16.Text = "Total Percepciones:";
            // 
            // txt_TOTDeducciones_RecPEmpleado
            // 
            this.txt_TOTDeducciones_RecPEmpleado.Location = new System.Drawing.Point(534, 414);
            this.txt_TOTDeducciones_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_TOTDeducciones_RecPEmpleado.Name = "txt_TOTDeducciones_RecPEmpleado";
            this.txt_TOTDeducciones_RecPEmpleado.Size = new System.Drawing.Size(158, 22);
            this.txt_TOTDeducciones_RecPEmpleado.TabIndex = 138;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(354, 414);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(172, 20);
            this.label17.TabIndex = 139;
            this.label17.Text = "Total Deducciones:";
            // 
            // txt_Neto_RecPEmpleado
            // 
            this.txt_Neto_RecPEmpleado.Location = new System.Drawing.Point(325, 465);
            this.txt_Neto_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Neto_RecPEmpleado.Name = "txt_Neto_RecPEmpleado";
            this.txt_Neto_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Neto_RecPEmpleado.TabIndex = 140;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(198, 467);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(102, 20);
            this.label18.TabIndex = 141;
            this.label18.Text = "Total Neto:";
            // 
            // txt_IMSS_RecPEmpleado
            // 
            this.txt_IMSS_RecPEmpleado.Location = new System.Drawing.Point(78, 197);
            this.txt_IMSS_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_IMSS_RecPEmpleado.Name = "txt_IMSS_RecPEmpleado";
            this.txt_IMSS_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_IMSS_RecPEmpleado.TabIndex = 142;
            // 
            // btn_Regresar_RecEmpleado
            // 
            this.btn_Regresar_RecEmpleado.Location = new System.Drawing.Point(392, 509);
            this.btn_Regresar_RecEmpleado.Name = "btn_Regresar_RecEmpleado";
            this.btn_Regresar_RecEmpleado.Size = new System.Drawing.Size(105, 34);
            this.btn_Regresar_RecEmpleado.TabIndex = 143;
            this.btn_Regresar_RecEmpleado.Text = "Regresar";
            this.btn_Regresar_RecEmpleado.UseVisualStyleBackColor = true;
            this.btn_Regresar_RecEmpleado.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_Bruto_RecPEmpleado
            // 
            this.txt_Bruto_RecPEmpleado.Location = new System.Drawing.Point(545, 141);
            this.txt_Bruto_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Bruto_RecPEmpleado.Name = "txt_Bruto_RecPEmpleado";
            this.txt_Bruto_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_Bruto_RecPEmpleado.TabIndex = 145;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(403, 141);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 20);
            this.label8.TabIndex = 146;
            this.label8.Text = "Sueldo Burto:";
            // 
            // txt_SalarioDiario_RecPEmpleado
            // 
            this.txt_SalarioDiario_RecPEmpleado.Location = new System.Drawing.Point(545, 102);
            this.txt_SalarioDiario_RecPEmpleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SalarioDiario_RecPEmpleado.Name = "txt_SalarioDiario_RecPEmpleado";
            this.txt_SalarioDiario_RecPEmpleado.Size = new System.Drawing.Size(181, 22);
            this.txt_SalarioDiario_RecPEmpleado.TabIndex = 147;
            this.txt_SalarioDiario_RecPEmpleado.TextChanged += new System.EventHandler(this.txt_SalarioDiario_RecPEmpleado_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(403, 102);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(131, 20);
            this.label19.TabIndex = 148;
            this.label19.Text = "Salario Diario:";
            // 
            // P_ReciboEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 562);
            this.ControlBox = false;
            this.Controls.Add(this.txt_SalarioDiario_RecPEmpleado);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txt_Bruto_RecPEmpleado);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn_Regresar_RecEmpleado);
            this.Controls.Add(this.txt_IMSS_RecPEmpleado);
            this.Controls.Add(this.txt_Neto_RecPEmpleado);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txt_TOTDeducciones_RecPEmpleado);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txt_TOTPercepciones_RecPEmpleado);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txt_DiasTrabajados_RecPEmpleado);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_NumCuenta_RecPEmpleado);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_Banco_RecPEmpleado);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_Puesto_RecPEmpleado);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_Departamento_RecPEmpleado);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_Curp_RecPEmpleado);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_RFC_RecPEmpleado);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_NumEmpleadoMostrar_RecPEmpleado);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_Nombre_RecPEmpleado);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Imprimir_RecPEmpleado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Buscar_RecPEmpleado);
            this.Controls.Add(this.txt_NumEmpleado_RecPEmpleado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Ano_RecPEmpleado);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.combo_Mes);
            this.Controls.Add(this.label9);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_ReciboEmpleado";
            this.Text = "Recibo Por Empleado";
            this.Load += new System.EventHandler(this.P_ReciboEmpleado_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Buscar_RecPEmpleado;
        private System.Windows.Forms.TextBox txt_NumEmpleado_RecPEmpleado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Ano_RecPEmpleado;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox combo_Mes;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Imprimir_RecPEmpleado;
        private System.Windows.Forms.TextBox txt_Nombre_RecPEmpleado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_NumEmpleadoMostrar_RecPEmpleado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_RFC_RecPEmpleado;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_Curp_RecPEmpleado;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Departamento_RecPEmpleado;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_Puesto_RecPEmpleado;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_Banco_RecPEmpleado;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_NumCuenta_RecPEmpleado;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_DiasTrabajados_RecPEmpleado;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_TOTPercepciones_RecPEmpleado;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_TOTDeducciones_RecPEmpleado;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_Neto_RecPEmpleado;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_IMSS_RecPEmpleado;
        private System.Windows.Forms.Button btn_Regresar_RecEmpleado;
        private System.Windows.Forms.TextBox txt_Bruto_RecPEmpleado;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_SalarioDiario_RecPEmpleado;
        private System.Windows.Forms.Label label19;
    }
}