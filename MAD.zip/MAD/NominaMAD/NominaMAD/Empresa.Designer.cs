﻿namespace NominaMAD
{
    partial class P_Empresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Nombre_Empresa = new System.Windows.Forms.TextBox();
            this.txt_RazonSocial_Empresa = new System.Windows.Forms.TextBox();
            this.txt_DomFiscal_Empresa = new System.Windows.Forms.TextBox();
            this.txt_Telelfono_Empresa = new System.Windows.Forms.TextBox();
            this.txt_RegistroPeatronal_Empresa = new System.Windows.Forms.TextBox();
            this.txt_RFC_Empresa = new System.Windows.Forms.TextBox();
            this.dtp_FechaInOpera_Empresa = new System.Windows.Forms.DateTimePicker();
            this.btn_Regresar_Empresa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Razon Social:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Domicilio Fiscal:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Registro Peatronal:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telefono:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "RFC:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(199, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Fecha de inicio de operaciones:";
            // 
            // txt_Nombre_Empresa
            // 
            this.txt_Nombre_Empresa.Location = new System.Drawing.Point(91, 27);
            this.txt_Nombre_Empresa.Name = "txt_Nombre_Empresa";
            this.txt_Nombre_Empresa.Size = new System.Drawing.Size(191, 22);
            this.txt_Nombre_Empresa.TabIndex = 7;
            // 
            // txt_RazonSocial_Empresa
            // 
            this.txt_RazonSocial_Empresa.Location = new System.Drawing.Point(116, 74);
            this.txt_RazonSocial_Empresa.Name = "txt_RazonSocial_Empresa";
            this.txt_RazonSocial_Empresa.Size = new System.Drawing.Size(176, 22);
            this.txt_RazonSocial_Empresa.TabIndex = 8;
            // 
            // txt_DomFiscal_Empresa
            // 
            this.txt_DomFiscal_Empresa.Location = new System.Drawing.Point(125, 126);
            this.txt_DomFiscal_Empresa.Name = "txt_DomFiscal_Empresa";
            this.txt_DomFiscal_Empresa.Size = new System.Drawing.Size(200, 22);
            this.txt_DomFiscal_Empresa.TabIndex = 9;
            // 
            // txt_Telelfono_Empresa
            // 
            this.txt_Telelfono_Empresa.Location = new System.Drawing.Point(91, 261);
            this.txt_Telelfono_Empresa.Name = "txt_Telelfono_Empresa";
            this.txt_Telelfono_Empresa.Size = new System.Drawing.Size(164, 22);
            this.txt_Telelfono_Empresa.TabIndex = 10;
            // 
            // txt_RegistroPeatronal_Empresa
            // 
            this.txt_RegistroPeatronal_Empresa.Location = new System.Drawing.Point(146, 173);
            this.txt_RegistroPeatronal_Empresa.Name = "txt_RegistroPeatronal_Empresa";
            this.txt_RegistroPeatronal_Empresa.Size = new System.Drawing.Size(179, 22);
            this.txt_RegistroPeatronal_Empresa.TabIndex = 11;
            // 
            // txt_RFC_Empresa
            // 
            this.txt_RFC_Empresa.Location = new System.Drawing.Point(91, 219);
            this.txt_RFC_Empresa.Name = "txt_RFC_Empresa";
            this.txt_RFC_Empresa.Size = new System.Drawing.Size(140, 22);
            this.txt_RFC_Empresa.TabIndex = 12;
            // 
            // dtp_FechaInOpera_Empresa
            // 
            this.dtp_FechaInOpera_Empresa.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_FechaInOpera_Empresa.Location = new System.Drawing.Point(219, 360);
            this.dtp_FechaInOpera_Empresa.Name = "dtp_FechaInOpera_Empresa";
            this.dtp_FechaInOpera_Empresa.Size = new System.Drawing.Size(111, 22);
            this.dtp_FechaInOpera_Empresa.TabIndex = 13;
            this.dtp_FechaInOpera_Empresa.ValueChanged += new System.EventHandler(this.dtp_FechaInOpera_Empresa_ValueChanged);
            // 
            // btn_Regresar_Empresa
            // 
            this.btn_Regresar_Empresa.Location = new System.Drawing.Point(146, 464);
            this.btn_Regresar_Empresa.Name = "btn_Regresar_Empresa";
            this.btn_Regresar_Empresa.Size = new System.Drawing.Size(92, 42);
            this.btn_Regresar_Empresa.TabIndex = 14;
            this.btn_Regresar_Empresa.Text = "Regresar";
            this.btn_Regresar_Empresa.UseVisualStyleBackColor = true;
            this.btn_Regresar_Empresa.Click += new System.EventHandler(this.btn_Regresar_Empresa_Click);
            // 
            // P_Empresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 545);
            this.Controls.Add(this.btn_Regresar_Empresa);
            this.Controls.Add(this.dtp_FechaInOpera_Empresa);
            this.Controls.Add(this.txt_RFC_Empresa);
            this.Controls.Add(this.txt_RegistroPeatronal_Empresa);
            this.Controls.Add(this.txt_Telelfono_Empresa);
            this.Controls.Add(this.txt_DomFiscal_Empresa);
            this.Controls.Add(this.txt_RazonSocial_Empresa);
            this.Controls.Add(this.txt_Nombre_Empresa);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "P_Empresa";
            this.Text = "Empresa";
            this.Load += new System.EventHandler(this.P_Empresa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Nombre_Empresa;
        private System.Windows.Forms.TextBox txt_RazonSocial_Empresa;
        private System.Windows.Forms.TextBox txt_DomFiscal_Empresa;
        private System.Windows.Forms.TextBox txt_Telelfono_Empresa;
        private System.Windows.Forms.TextBox txt_RegistroPeatronal_Empresa;
        private System.Windows.Forms.TextBox txt_RFC_Empresa;
        private System.Windows.Forms.DateTimePicker dtp_FechaInOpera_Empresa;
        private System.Windows.Forms.Button btn_Regresar_Empresa;
    }
}