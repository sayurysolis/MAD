﻿namespace NominaMAD
{
    partial class P_Menu2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox_Admin_MENU2 = new System.Windows.Forms.CheckBox();
            this.btn_Salir_MENU2 = new System.Windows.Forms.Button();
            this.btn_ReciboEmpleado_MENU2 = new System.Windows.Forms.Button();
            this.btn_GestionEmpleados_MENU2 = new System.Windows.Forms.Button();
            this.text_NombreUsuario_MENU2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkBox_Admin_MENU2
            // 
            this.checkBox_Admin_MENU2.AutoSize = true;
            this.checkBox_Admin_MENU2.Checked = true;
            this.checkBox_Admin_MENU2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Admin_MENU2.Enabled = false;
            this.checkBox_Admin_MENU2.Location = new System.Drawing.Point(611, 92);
            this.checkBox_Admin_MENU2.Name = "checkBox_Admin_MENU2";
            this.checkBox_Admin_MENU2.Size = new System.Drawing.Size(92, 20);
            this.checkBox_Admin_MENU2.TabIndex = 31;
            this.checkBox_Admin_MENU2.Text = "Empleado";
            this.checkBox_Admin_MENU2.UseVisualStyleBackColor = true;
            // 
            // btn_Salir_MENU2
            // 
            this.btn_Salir_MENU2.Location = new System.Drawing.Point(285, 339);
            this.btn_Salir_MENU2.Name = "btn_Salir_MENU2";
            this.btn_Salir_MENU2.Size = new System.Drawing.Size(196, 54);
            this.btn_Salir_MENU2.TabIndex = 28;
            this.btn_Salir_MENU2.Text = "Salir";
            this.btn_Salir_MENU2.UseVisualStyleBackColor = true;
            // 
            // btn_ReciboEmpleado_MENU2
            // 
            this.btn_ReciboEmpleado_MENU2.Location = new System.Drawing.Point(267, 278);
            this.btn_ReciboEmpleado_MENU2.Name = "btn_ReciboEmpleado_MENU2";
            this.btn_ReciboEmpleado_MENU2.Size = new System.Drawing.Size(238, 55);
            this.btn_ReciboEmpleado_MENU2.TabIndex = 27;
            this.btn_ReciboEmpleado_MENU2.Text = "Recibo por Empleado";
            this.btn_ReciboEmpleado_MENU2.UseVisualStyleBackColor = true;
            // 
            // btn_GestionEmpleados_MENU2
            // 
            this.btn_GestionEmpleados_MENU2.Location = new System.Drawing.Point(254, 215);
            this.btn_GestionEmpleados_MENU2.Name = "btn_GestionEmpleados_MENU2";
            this.btn_GestionEmpleados_MENU2.Size = new System.Drawing.Size(260, 57);
            this.btn_GestionEmpleados_MENU2.TabIndex = 26;
            this.btn_GestionEmpleados_MENU2.Text = "Gestions de Empleados";
            this.btn_GestionEmpleados_MENU2.UseVisualStyleBackColor = true;
            // 
            // text_NombreUsuario_MENU2
            // 
            this.text_NombreUsuario_MENU2.Enabled = false;
            this.text_NombreUsuario_MENU2.Location = new System.Drawing.Point(295, 90);
            this.text_NombreUsuario_MENU2.Name = "text_NombreUsuario_MENU2";
            this.text_NombreUsuario_MENU2.Size = new System.Drawing.Size(246, 22);
            this.text_NombreUsuario_MENU2.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(80, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "Nombre De Usuario:";
            // 
            // P_Menu2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 528);
            this.Controls.Add(this.checkBox_Admin_MENU2);
            this.Controls.Add(this.btn_Salir_MENU2);
            this.Controls.Add(this.btn_ReciboEmpleado_MENU2);
            this.Controls.Add(this.btn_GestionEmpleados_MENU2);
            this.Controls.Add(this.text_NombreUsuario_MENU2);
            this.Controls.Add(this.label2);
            this.Name = "P_Menu2";
            this.Text = "MENU";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox_Admin_MENU2;
        private System.Windows.Forms.Button btn_Salir_MENU2;
        private System.Windows.Forms.Button btn_ReciboEmpleado_MENU2;
        private System.Windows.Forms.Button btn_GestionEmpleados_MENU2;
        private System.Windows.Forms.TextBox text_NombreUsuario_MENU2;
        private System.Windows.Forms.Label label2;
    }
}