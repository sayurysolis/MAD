﻿namespace NominaMAD
{
    partial class P_Menu1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox_Admin_MENU1 = new System.Windows.Forms.CheckBox();
            this.btn_Salir_MENU1 = new System.Windows.Forms.Button();
            this.btn_ReciboEmpleado_MENU1 = new System.Windows.Forms.Button();
            this.btn_ReporteHeadcounter_MENU1 = new System.Windows.Forms.Button();
            this.btn_ReporteGenNomina_MENU1 = new System.Windows.Forms.Button();
            this.btn_GestionEmpleados_MENU1 = new System.Windows.Forms.Button();
            this.btn_GestionPuestos_MENU1 = new System.Windows.Forms.Button();
            this.btn_GestionDepar_MENU1 = new System.Windows.Forms.Button();
            this.btn_ConceptosDedPer_MENU1 = new System.Windows.Forms.Button();
            this.btn_GenerarNomina_MENU1 = new System.Windows.Forms.Button();
            this.btn_Empresa_MENU1 = new System.Windows.Forms.Button();
            this.btn_RH_MENU1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkBox_Admin_MENU1
            // 
            this.checkBox_Admin_MENU1.AutoSize = true;
            this.checkBox_Admin_MENU1.Checked = true;
            this.checkBox_Admin_MENU1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Admin_MENU1.Enabled = false;
            this.checkBox_Admin_MENU1.Location = new System.Drawing.Point(566, 12);
            this.checkBox_Admin_MENU1.Name = "checkBox_Admin_MENU1";
            this.checkBox_Admin_MENU1.Size = new System.Drawing.Size(112, 20);
            this.checkBox_Admin_MENU1.TabIndex = 25;
            this.checkBox_Admin_MENU1.Text = "Administrador";
            this.checkBox_Admin_MENU1.UseVisualStyleBackColor = true;
            // 
            // btn_Salir_MENU1
            // 
            this.btn_Salir_MENU1.Location = new System.Drawing.Point(28, 385);
            this.btn_Salir_MENU1.Name = "btn_Salir_MENU1";
            this.btn_Salir_MENU1.Size = new System.Drawing.Size(173, 24);
            this.btn_Salir_MENU1.TabIndex = 24;
            this.btn_Salir_MENU1.Text = "Salir";
            this.btn_Salir_MENU1.UseVisualStyleBackColor = true;
            this.btn_Salir_MENU1.Click += new System.EventHandler(this.btn_Salir_MENU1_Click);
            // 
            // btn_ReciboEmpleado_MENU1
            // 
            this.btn_ReciboEmpleado_MENU1.Location = new System.Drawing.Point(330, 230);
            this.btn_ReciboEmpleado_MENU1.Name = "btn_ReciboEmpleado_MENU1";
            this.btn_ReciboEmpleado_MENU1.Size = new System.Drawing.Size(215, 25);
            this.btn_ReciboEmpleado_MENU1.TabIndex = 23;
            this.btn_ReciboEmpleado_MENU1.Text = "Recibo por Empleado";
            this.btn_ReciboEmpleado_MENU1.UseVisualStyleBackColor = true;
            this.btn_ReciboEmpleado_MENU1.Click += new System.EventHandler(this.btn_ReciboEmpleado_MENU1_Click);
            // 
            // btn_ReporteHeadcounter_MENU1
            // 
            this.btn_ReporteHeadcounter_MENU1.Location = new System.Drawing.Point(330, 165);
            this.btn_ReporteHeadcounter_MENU1.Name = "btn_ReporteHeadcounter_MENU1";
            this.btn_ReporteHeadcounter_MENU1.Size = new System.Drawing.Size(221, 25);
            this.btn_ReporteHeadcounter_MENU1.TabIndex = 21;
            this.btn_ReporteHeadcounter_MENU1.Text = "Reporte Headcounter";
            this.btn_ReporteHeadcounter_MENU1.UseVisualStyleBackColor = true;
            this.btn_ReporteHeadcounter_MENU1.Click += new System.EventHandler(this.btn_ReporteHeadcounter_MENU1_Click);
            // 
            // btn_ReporteGenNomina_MENU1
            // 
            this.btn_ReporteGenNomina_MENU1.Location = new System.Drawing.Point(330, 111);
            this.btn_ReporteGenNomina_MENU1.Name = "btn_ReporteGenNomina_MENU1";
            this.btn_ReporteGenNomina_MENU1.Size = new System.Drawing.Size(230, 26);
            this.btn_ReporteGenNomina_MENU1.TabIndex = 20;
            this.btn_ReporteGenNomina_MENU1.Text = "Reporte General de Nomina";
            this.btn_ReporteGenNomina_MENU1.UseVisualStyleBackColor = true;
            this.btn_ReporteGenNomina_MENU1.Click += new System.EventHandler(this.btn_ReporteGenNomina_MENU1_Click);
            // 
            // btn_GestionEmpleados_MENU1
            // 
            this.btn_GestionEmpleados_MENU1.Location = new System.Drawing.Point(28, 154);
            this.btn_GestionEmpleados_MENU1.Name = "btn_GestionEmpleados_MENU1";
            this.btn_GestionEmpleados_MENU1.Size = new System.Drawing.Size(237, 27);
            this.btn_GestionEmpleados_MENU1.TabIndex = 17;
            this.btn_GestionEmpleados_MENU1.Text = "Gestion de Empleados";
            this.btn_GestionEmpleados_MENU1.UseVisualStyleBackColor = true;
            this.btn_GestionEmpleados_MENU1.Click += new System.EventHandler(this.btn_GestionEmpleados_MENU1_Click);
            // 
            // btn_GestionPuestos_MENU1
            // 
            this.btn_GestionPuestos_MENU1.Location = new System.Drawing.Point(28, 254);
            this.btn_GestionPuestos_MENU1.Name = "btn_GestionPuestos_MENU1";
            this.btn_GestionPuestos_MENU1.Size = new System.Drawing.Size(239, 30);
            this.btn_GestionPuestos_MENU1.TabIndex = 16;
            this.btn_GestionPuestos_MENU1.Text = "Gestion de Puestos";
            this.btn_GestionPuestos_MENU1.UseVisualStyleBackColor = true;
            this.btn_GestionPuestos_MENU1.Click += new System.EventHandler(this.btn_GestionPuestos_MENU1_Click);
            // 
            // btn_GestionDepar_MENU1
            // 
            this.btn_GestionDepar_MENU1.Location = new System.Drawing.Point(28, 203);
            this.btn_GestionDepar_MENU1.Name = "btn_GestionDepar_MENU1";
            this.btn_GestionDepar_MENU1.Size = new System.Drawing.Size(235, 31);
            this.btn_GestionDepar_MENU1.TabIndex = 14;
            this.btn_GestionDepar_MENU1.Text = "Gestion de Departamento";
            this.btn_GestionDepar_MENU1.UseVisualStyleBackColor = true;
            this.btn_GestionDepar_MENU1.Click += new System.EventHandler(this.btn_GestionDepar_MENU1_Click);
            // 
            // btn_ConceptosDedPer_MENU1
            // 
            this.btn_ConceptosDedPer_MENU1.Location = new System.Drawing.Point(28, 314);
            this.btn_ConceptosDedPer_MENU1.Name = "btn_ConceptosDedPer_MENU1";
            this.btn_ConceptosDedPer_MENU1.Size = new System.Drawing.Size(261, 27);
            this.btn_ConceptosDedPer_MENU1.TabIndex = 26;
            this.btn_ConceptosDedPer_MENU1.Text = "Conceptos Deduciones Percepciones";
            this.btn_ConceptosDedPer_MENU1.UseVisualStyleBackColor = true;
            this.btn_ConceptosDedPer_MENU1.Click += new System.EventHandler(this.btn_ConceptosDedPer_MENU1_Click);
            // 
            // btn_GenerarNomina_MENU1
            // 
            this.btn_GenerarNomina_MENU1.Location = new System.Drawing.Point(330, 281);
            this.btn_GenerarNomina_MENU1.Name = "btn_GenerarNomina_MENU1";
            this.btn_GenerarNomina_MENU1.Size = new System.Drawing.Size(160, 27);
            this.btn_GenerarNomina_MENU1.TabIndex = 27;
            this.btn_GenerarNomina_MENU1.Text = "Generar Nomina";
            this.btn_GenerarNomina_MENU1.UseVisualStyleBackColor = true;
            this.btn_GenerarNomina_MENU1.Click += new System.EventHandler(this.btn_GenerarNomina_MENU1_Click);
            // 
            // btn_Empresa_MENU1
            // 
            this.btn_Empresa_MENU1.Location = new System.Drawing.Point(28, 106);
            this.btn_Empresa_MENU1.Name = "btn_Empresa_MENU1";
            this.btn_Empresa_MENU1.Size = new System.Drawing.Size(235, 31);
            this.btn_Empresa_MENU1.TabIndex = 28;
            this.btn_Empresa_MENU1.Text = "Empresa";
            this.btn_Empresa_MENU1.UseVisualStyleBackColor = true;
            this.btn_Empresa_MENU1.Click += new System.EventHandler(this.btn_Empresa_MENU1_Click);
            // 
            // btn_RH_MENU1
            // 
            this.btn_RH_MENU1.Location = new System.Drawing.Point(330, 341);
            this.btn_RH_MENU1.Name = "btn_RH_MENU1";
            this.btn_RH_MENU1.Size = new System.Drawing.Size(158, 30);
            this.btn_RH_MENU1.TabIndex = 29;
            this.btn_RH_MENU1.Text = "RH";
            this.btn_RH_MENU1.UseVisualStyleBackColor = true;
            this.btn_RH_MENU1.Click += new System.EventHandler(this.btn_RH_MENU1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(230, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 42);
            this.label2.TabIndex = 30;
            this.label2.Text = "DSB Topografia";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // P_Menu1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 422);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_RH_MENU1);
            this.Controls.Add(this.btn_Empresa_MENU1);
            this.Controls.Add(this.btn_GenerarNomina_MENU1);
            this.Controls.Add(this.btn_ConceptosDedPer_MENU1);
            this.Controls.Add(this.checkBox_Admin_MENU1);
            this.Controls.Add(this.btn_Salir_MENU1);
            this.Controls.Add(this.btn_ReciboEmpleado_MENU1);
            this.Controls.Add(this.btn_ReporteHeadcounter_MENU1);
            this.Controls.Add(this.btn_ReporteGenNomina_MENU1);
            this.Controls.Add(this.btn_GestionEmpleados_MENU1);
            this.Controls.Add(this.btn_GestionPuestos_MENU1);
            this.Controls.Add(this.btn_GestionDepar_MENU1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_Menu1";
            this.Text = "MENU";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox_Admin_MENU1;
        private System.Windows.Forms.Button btn_Salir_MENU1;
        private System.Windows.Forms.Button btn_ReciboEmpleado_MENU1;
        private System.Windows.Forms.Button btn_ReporteHeadcounter_MENU1;
        private System.Windows.Forms.Button btn_ReporteGenNomina_MENU1;
        private System.Windows.Forms.Button btn_GestionEmpleados_MENU1;
        private System.Windows.Forms.Button btn_GestionPuestos_MENU1;
        private System.Windows.Forms.Button btn_GestionDepar_MENU1;
        private System.Windows.Forms.Button btn_ConceptosDedPer_MENU1;
        private System.Windows.Forms.Button btn_GenerarNomina_MENU1;
        private System.Windows.Forms.Button btn_Empresa_MENU1;
        private System.Windows.Forms.Button btn_RH_MENU1;
        private System.Windows.Forms.Label label2;
    }
}