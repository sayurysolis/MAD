﻿namespace NominaMAD
{
    partial class P_GestionDepar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgv_GestionDepar = new System.Windows.Forms.DataGridView();
            this.btn_CancelarMod_GestionDepar = new System.Windows.Forms.Button();
            this.btn_AceptarMod_GestionDepar = new System.Windows.Forms.Button();
            this.btn_Agregar_GestionDepar = new System.Windows.Forms.Button();
            this.btn_Modificar_GestionDepar = new System.Windows.Forms.Button();
            this.btn_Regresar_GestionDepar = new System.Windows.Forms.Button();
            this.btn_limpiar_GestionDepar = new System.Windows.Forms.Button();
            this.btn_Guardar_GestionDepar = new System.Windows.Forms.Button();
            this.txt_Departamento_GestDepar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_GestionDepar)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgv_GestionDepar
            // 
            this.dtgv_GestionDepar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_GestionDepar.Location = new System.Drawing.Point(14, 179);
            this.dtgv_GestionDepar.Name = "dtgv_GestionDepar";
            this.dtgv_GestionDepar.ReadOnly = true;
            this.dtgv_GestionDepar.RowHeadersWidth = 51;
            this.dtgv_GestionDepar.RowTemplate.Height = 24;
            this.dtgv_GestionDepar.Size = new System.Drawing.Size(549, 211);
            this.dtgv_GestionDepar.TabIndex = 0;
            this.dtgv_GestionDepar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_GestionDepar_CellClick);
            // 
            // btn_CancelarMod_GestionDepar
            // 
            this.btn_CancelarMod_GestionDepar.Location = new System.Drawing.Point(176, 133);
            this.btn_CancelarMod_GestionDepar.Name = "btn_CancelarMod_GestionDepar";
            this.btn_CancelarMod_GestionDepar.Size = new System.Drawing.Size(163, 28);
            this.btn_CancelarMod_GestionDepar.TabIndex = 30;
            this.btn_CancelarMod_GestionDepar.Text = "Cancelar Modificacion";
            this.btn_CancelarMod_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_CancelarMod_GestionDepar.Click += new System.EventHandler(this.btn_CancelarMod_GestionDepar_Click);
            // 
            // btn_AceptarMod_GestionDepar
            // 
            this.btn_AceptarMod_GestionDepar.Location = new System.Drawing.Point(15, 133);
            this.btn_AceptarMod_GestionDepar.Name = "btn_AceptarMod_GestionDepar";
            this.btn_AceptarMod_GestionDepar.Size = new System.Drawing.Size(155, 27);
            this.btn_AceptarMod_GestionDepar.TabIndex = 29;
            this.btn_AceptarMod_GestionDepar.Text = "Aceptar Modificacion ";
            this.btn_AceptarMod_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_AceptarMod_GestionDepar.Click += new System.EventHandler(this.btn_AceptarMod_GestionDepar_Click);
            // 
            // btn_Agregar_GestionDepar
            // 
            this.btn_Agregar_GestionDepar.Location = new System.Drawing.Point(356, 35);
            this.btn_Agregar_GestionDepar.Name = "btn_Agregar_GestionDepar";
            this.btn_Agregar_GestionDepar.Size = new System.Drawing.Size(86, 30);
            this.btn_Agregar_GestionDepar.TabIndex = 28;
            this.btn_Agregar_GestionDepar.Text = "Agregar";
            this.btn_Agregar_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_Agregar_GestionDepar.Click += new System.EventHandler(this.btn_Agregar_GestionDepar_Click);
            // 
            // btn_Modificar_GestionDepar
            // 
            this.btn_Modificar_GestionDepar.Location = new System.Drawing.Point(117, 81);
            this.btn_Modificar_GestionDepar.Name = "btn_Modificar_GestionDepar";
            this.btn_Modificar_GestionDepar.Size = new System.Drawing.Size(99, 34);
            this.btn_Modificar_GestionDepar.TabIndex = 27;
            this.btn_Modificar_GestionDepar.Text = "Modificar";
            this.btn_Modificar_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_Modificar_GestionDepar.Click += new System.EventHandler(this.btn_Modificar_GestionDepar_Click);
            // 
            // btn_Regresar_GestionDepar
            // 
            this.btn_Regresar_GestionDepar.Location = new System.Drawing.Point(367, 122);
            this.btn_Regresar_GestionDepar.Name = "btn_Regresar_GestionDepar";
            this.btn_Regresar_GestionDepar.Size = new System.Drawing.Size(96, 38);
            this.btn_Regresar_GestionDepar.TabIndex = 26;
            this.btn_Regresar_GestionDepar.Text = "Regresar";
            this.btn_Regresar_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_Regresar_GestionDepar.Click += new System.EventHandler(this.btn_Regresar_GestionDepar_Click);
            // 
            // btn_limpiar_GestionDepar
            // 
            this.btn_limpiar_GestionDepar.Location = new System.Drawing.Point(222, 83);
            this.btn_limpiar_GestionDepar.Name = "btn_limpiar_GestionDepar";
            this.btn_limpiar_GestionDepar.Size = new System.Drawing.Size(97, 34);
            this.btn_limpiar_GestionDepar.TabIndex = 25;
            this.btn_limpiar_GestionDepar.Text = "Limpiar";
            this.btn_limpiar_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_limpiar_GestionDepar.Click += new System.EventHandler(this.btn_limpiar_GestionDepar_Click);
            // 
            // btn_Guardar_GestionDepar
            // 
            this.btn_Guardar_GestionDepar.Location = new System.Drawing.Point(12, 83);
            this.btn_Guardar_GestionDepar.Name = "btn_Guardar_GestionDepar";
            this.btn_Guardar_GestionDepar.Size = new System.Drawing.Size(99, 30);
            this.btn_Guardar_GestionDepar.TabIndex = 24;
            this.btn_Guardar_GestionDepar.Text = "Guardar";
            this.btn_Guardar_GestionDepar.UseVisualStyleBackColor = true;
            this.btn_Guardar_GestionDepar.Click += new System.EventHandler(this.btn_Guardar_GestionDepar_Click);
            // 
            // txt_Departamento_GestDepar
            // 
            this.txt_Departamento_GestDepar.Location = new System.Drawing.Point(176, 43);
            this.txt_Departamento_GestDepar.Name = "txt_Departamento_GestDepar";
            this.txt_Departamento_GestDepar.Size = new System.Drawing.Size(158, 22);
            this.txt_Departamento_GestDepar.TabIndex = 21;
            this.txt_Departamento_GestDepar.TextChanged += new System.EventHandler(this.txt_Departamento_GestDepar_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Departamento: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Datos a Ingresar:";
            // 
            // P_GestionDepar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 402);
            this.ControlBox = false;
            this.Controls.Add(this.btn_CancelarMod_GestionDepar);
            this.Controls.Add(this.btn_AceptarMod_GestionDepar);
            this.Controls.Add(this.btn_Agregar_GestionDepar);
            this.Controls.Add(this.btn_Modificar_GestionDepar);
            this.Controls.Add(this.btn_Regresar_GestionDepar);
            this.Controls.Add(this.btn_limpiar_GestionDepar);
            this.Controls.Add(this.btn_Guardar_GestionDepar);
            this.Controls.Add(this.txt_Departamento_GestDepar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtgv_GestionDepar);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_GestionDepar";
            this.Text = "Gestion de Departamentos";
            this.Load += new System.EventHandler(this.P_GestionDepar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_GestionDepar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgv_GestionDepar;
        private System.Windows.Forms.Button btn_CancelarMod_GestionDepar;
        private System.Windows.Forms.Button btn_AceptarMod_GestionDepar;
        private System.Windows.Forms.Button btn_Agregar_GestionDepar;
        private System.Windows.Forms.Button btn_Modificar_GestionDepar;
        private System.Windows.Forms.Button btn_Regresar_GestionDepar;
        private System.Windows.Forms.Button btn_limpiar_GestionDepar;
        private System.Windows.Forms.Button btn_Guardar_GestionDepar;
        private System.Windows.Forms.TextBox txt_Departamento_GestDepar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}