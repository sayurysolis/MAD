﻿namespace NominaMAD
{
    partial class P_GestionPuestos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Regresar_GestionPuestos = new System.Windows.Forms.Button();
            this.btn_Modifcar_GestionPuestos = new System.Windows.Forms.Button();
            this.btn_Limpiar_GestionPuestos = new System.Windows.Forms.Button();
            this.btn_Guardar_GestionPuestos = new System.Windows.Forms.Button();
            this.txt_DescripcionPuesto_GestionPuestos = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmBox_Departamento_GestionPuestos = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtgv_GestionPustos = new System.Windows.Forms.DataGridView();
            this.txtPuesto_GestionPuestos = new System.Windows.Forms.TextBox();
            this.btn_Agregar_GestionPuestos = new System.Windows.Forms.Button();
            this.btn_AceptarMOD_GestionPuestos = new System.Windows.Forms.Button();
            this.btn_CancelarMOD_GestionPuestos = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_GestionPustos)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Regresar_GestionPuestos
            // 
            this.btn_Regresar_GestionPuestos.Location = new System.Drawing.Point(673, 512);
            this.btn_Regresar_GestionPuestos.Name = "btn_Regresar_GestionPuestos";
            this.btn_Regresar_GestionPuestos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Regresar_GestionPuestos.Size = new System.Drawing.Size(92, 34);
            this.btn_Regresar_GestionPuestos.TabIndex = 31;
            this.btn_Regresar_GestionPuestos.Text = "Regresar";
            this.btn_Regresar_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_Regresar_GestionPuestos.Click += new System.EventHandler(this.btn_Regresar_GestionPuestos_Click);
            // 
            // btn_Modifcar_GestionPuestos
            // 
            this.btn_Modifcar_GestionPuestos.Location = new System.Drawing.Point(660, 401);
            this.btn_Modifcar_GestionPuestos.Name = "btn_Modifcar_GestionPuestos";
            this.btn_Modifcar_GestionPuestos.Size = new System.Drawing.Size(85, 29);
            this.btn_Modifcar_GestionPuestos.TabIndex = 30;
            this.btn_Modifcar_GestionPuestos.Text = "Modificar";
            this.btn_Modifcar_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_Modifcar_GestionPuestos.Click += new System.EventHandler(this.btn_Modifcar_GestionPuestos_Click);
            // 
            // btn_Limpiar_GestionPuestos
            // 
            this.btn_Limpiar_GestionPuestos.Location = new System.Drawing.Point(660, 436);
            this.btn_Limpiar_GestionPuestos.Name = "btn_Limpiar_GestionPuestos";
            this.btn_Limpiar_GestionPuestos.Size = new System.Drawing.Size(83, 28);
            this.btn_Limpiar_GestionPuestos.TabIndex = 29;
            this.btn_Limpiar_GestionPuestos.Text = "Limpiar";
            this.btn_Limpiar_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_Limpiar_GestionPuestos.Click += new System.EventHandler(this.btn_Limpiar_GestionPuestos_Click);
            // 
            // btn_Guardar_GestionPuestos
            // 
            this.btn_Guardar_GestionPuestos.Location = new System.Drawing.Point(660, 371);
            this.btn_Guardar_GestionPuestos.Name = "btn_Guardar_GestionPuestos";
            this.btn_Guardar_GestionPuestos.Size = new System.Drawing.Size(81, 27);
            this.btn_Guardar_GestionPuestos.TabIndex = 28;
            this.btn_Guardar_GestionPuestos.Text = "Guardar";
            this.btn_Guardar_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_Guardar_GestionPuestos.Click += new System.EventHandler(this.btn_Guardar_GestionPuestos_Click);
            // 
            // txt_DescripcionPuesto_GestionPuestos
            // 
            this.txt_DescripcionPuesto_GestionPuestos.Location = new System.Drawing.Point(193, 442);
            this.txt_DescripcionPuesto_GestionPuestos.Name = "txt_DescripcionPuesto_GestionPuestos";
            this.txt_DescripcionPuesto_GestionPuestos.Size = new System.Drawing.Size(421, 22);
            this.txt_DescripcionPuesto_GestionPuestos.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 442);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "Descripcion:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(71, 401);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 20);
            this.label4.TabIndex = 22;
            this.label4.Text = "Puesto: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 367);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Datos a ingresar: ";
            // 
            // cmBox_Departamento_GestionPuestos
            // 
            this.cmBox_Departamento_GestionPuestos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBox_Departamento_GestionPuestos.FormattingEnabled = true;
            this.cmBox_Departamento_GestionPuestos.Location = new System.Drawing.Point(193, 46);
            this.cmBox_Departamento_GestionPuestos.Name = "cmBox_Departamento_GestionPuestos";
            this.cmBox_Departamento_GestionPuestos.Size = new System.Drawing.Size(297, 24);
            this.cmBox_Departamento_GestionPuestos.TabIndex = 19;
            this.cmBox_Departamento_GestionPuestos.SelectedIndexChanged += new System.EventHandler(this.cmBox_Departamento_GestionPuestos_SelectedIndexChanged_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Departamento:";
            // 
            // dtgv_GestionPustos
            // 
            this.dtgv_GestionPustos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_GestionPustos.Location = new System.Drawing.Point(222, 106);
            this.dtgv_GestionPustos.Name = "dtgv_GestionPustos";
            this.dtgv_GestionPustos.ReadOnly = true;
            this.dtgv_GestionPustos.RowHeadersWidth = 51;
            this.dtgv_GestionPustos.RowTemplate.Height = 24;
            this.dtgv_GestionPustos.Size = new System.Drawing.Size(630, 208);
            this.dtgv_GestionPustos.TabIndex = 32;
            this.dtgv_GestionPustos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_GestionPustos_CellClick);
            // 
            // txtPuesto_GestionPuestos
            // 
            this.txtPuesto_GestionPuestos.Location = new System.Drawing.Point(193, 401);
            this.txtPuesto_GestionPuestos.Name = "txtPuesto_GestionPuestos";
            this.txtPuesto_GestionPuestos.Size = new System.Drawing.Size(136, 22);
            this.txtPuesto_GestionPuestos.TabIndex = 33;
            // 
            // btn_Agregar_GestionPuestos
            // 
            this.btn_Agregar_GestionPuestos.Location = new System.Drawing.Point(193, 494);
            this.btn_Agregar_GestionPuestos.Name = "btn_Agregar_GestionPuestos";
            this.btn_Agregar_GestionPuestos.Size = new System.Drawing.Size(88, 32);
            this.btn_Agregar_GestionPuestos.TabIndex = 34;
            this.btn_Agregar_GestionPuestos.Text = "Agregar";
            this.btn_Agregar_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_Agregar_GestionPuestos.Click += new System.EventHandler(this.btn_Agregar_GestionPuestos_Click);
            // 
            // btn_AceptarMOD_GestionPuestos
            // 
            this.btn_AceptarMOD_GestionPuestos.Location = new System.Drawing.Point(867, 367);
            this.btn_AceptarMOD_GestionPuestos.Name = "btn_AceptarMOD_GestionPuestos";
            this.btn_AceptarMOD_GestionPuestos.Size = new System.Drawing.Size(142, 29);
            this.btn_AceptarMOD_GestionPuestos.TabIndex = 35;
            this.btn_AceptarMOD_GestionPuestos.Text = "Aceptar Modifcar";
            this.btn_AceptarMOD_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_AceptarMOD_GestionPuestos.Click += new System.EventHandler(this.btn_AceptarMOD_GestionPuestos_Click);
            // 
            // btn_CancelarMOD_GestionPuestos
            // 
            this.btn_CancelarMOD_GestionPuestos.Location = new System.Drawing.Point(865, 436);
            this.btn_CancelarMOD_GestionPuestos.Name = "btn_CancelarMOD_GestionPuestos";
            this.btn_CancelarMOD_GestionPuestos.Size = new System.Drawing.Size(152, 27);
            this.btn_CancelarMOD_GestionPuestos.TabIndex = 36;
            this.btn_CancelarMOD_GestionPuestos.Text = "Cancelar Modificacion";
            this.btn_CancelarMOD_GestionPuestos.UseVisualStyleBackColor = true;
            this.btn_CancelarMOD_GestionPuestos.Click += new System.EventHandler(this.btn_CancelarMOD_GestionPuestos_Click);
            // 
            // P_GestionPuestos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 622);
            this.ControlBox = false;
            this.Controls.Add(this.btn_CancelarMOD_GestionPuestos);
            this.Controls.Add(this.btn_AceptarMOD_GestionPuestos);
            this.Controls.Add(this.btn_Agregar_GestionPuestos);
            this.Controls.Add(this.txtPuesto_GestionPuestos);
            this.Controls.Add(this.dtgv_GestionPustos);
            this.Controls.Add(this.btn_Regresar_GestionPuestos);
            this.Controls.Add(this.btn_Modifcar_GestionPuestos);
            this.Controls.Add(this.btn_Limpiar_GestionPuestos);
            this.Controls.Add(this.btn_Guardar_GestionPuestos);
            this.Controls.Add(this.txt_DescripcionPuesto_GestionPuestos);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmBox_Departamento_GestionPuestos);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_GestionPuestos";
            this.Text = "Gestion de Puestos";
            this.Load += new System.EventHandler(this.P_GestionPuestos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_GestionPustos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Regresar_GestionPuestos;
        private System.Windows.Forms.Button btn_Modifcar_GestionPuestos;
        private System.Windows.Forms.Button btn_Limpiar_GestionPuestos;
        private System.Windows.Forms.Button btn_Guardar_GestionPuestos;
        private System.Windows.Forms.TextBox txt_DescripcionPuesto_GestionPuestos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmBox_Departamento_GestionPuestos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dtgv_GestionPustos;
        private System.Windows.Forms.TextBox txtPuesto_GestionPuestos;
        private System.Windows.Forms.Button btn_Agregar_GestionPuestos;
        private System.Windows.Forms.Button btn_AceptarMOD_GestionPuestos;
        private System.Windows.Forms.Button btn_CancelarMOD_GestionPuestos;
    }
}