﻿namespace NominaMAD
{
    partial class P_Menu2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox_Admin_MENU2 = new System.Windows.Forms.CheckBox();
            this.btn_Salir_MENU2 = new System.Windows.Forms.Button();
            this.btn_ReciboEmpleado_MENU2 = new System.Windows.Forms.Button();
            this.btn_GestionEmpleados_MENU2 = new System.Windows.Forms.Button();
            this.text_NombreUsuario_MENU2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_GenerarNomina_MENU1 = new System.Windows.Forms.Button();
            this.btn_ConceptosDedPer_MENU1 = new System.Windows.Forms.Button();
            this.btn_ReporteHeadcounter_MENU1 = new System.Windows.Forms.Button();
            this.btn_ReporteGenNomina_MENU1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_GestionPuestos_MENU2 = new System.Windows.Forms.Button();
            this.btn_GestionDepar_MENU2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkBox_Admin_MENU2
            // 
            this.checkBox_Admin_MENU2.AutoSize = true;
            this.checkBox_Admin_MENU2.Checked = true;
            this.checkBox_Admin_MENU2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Admin_MENU2.Enabled = false;
            this.checkBox_Admin_MENU2.Location = new System.Drawing.Point(548, 124);
            this.checkBox_Admin_MENU2.Name = "checkBox_Admin_MENU2";
            this.checkBox_Admin_MENU2.Size = new System.Drawing.Size(49, 20);
            this.checkBox_Admin_MENU2.TabIndex = 31;
            this.checkBox_Admin_MENU2.Text = "RH";
            this.checkBox_Admin_MENU2.UseVisualStyleBackColor = true;
            // 
            // btn_Salir_MENU2
            // 
            this.btn_Salir_MENU2.Location = new System.Drawing.Point(252, 472);
            this.btn_Salir_MENU2.Name = "btn_Salir_MENU2";
            this.btn_Salir_MENU2.Size = new System.Drawing.Size(196, 29);
            this.btn_Salir_MENU2.TabIndex = 28;
            this.btn_Salir_MENU2.Text = "Salir";
            this.btn_Salir_MENU2.UseVisualStyleBackColor = true;
            this.btn_Salir_MENU2.Click += new System.EventHandler(this.btn_Salir_MENU2_Click);
            // 
            // btn_ReciboEmpleado_MENU2
            // 
            this.btn_ReciboEmpleado_MENU2.Location = new System.Drawing.Point(424, 309);
            this.btn_ReciboEmpleado_MENU2.Name = "btn_ReciboEmpleado_MENU2";
            this.btn_ReciboEmpleado_MENU2.Size = new System.Drawing.Size(238, 25);
            this.btn_ReciboEmpleado_MENU2.TabIndex = 27;
            this.btn_ReciboEmpleado_MENU2.Text = "Recibo por Empleado";
            this.btn_ReciboEmpleado_MENU2.UseVisualStyleBackColor = true;
            this.btn_ReciboEmpleado_MENU2.Click += new System.EventHandler(this.btn_ReciboEmpleado_MENU2_Click);
            // 
            // btn_GestionEmpleados_MENU2
            // 
            this.btn_GestionEmpleados_MENU2.Location = new System.Drawing.Point(41, 176);
            this.btn_GestionEmpleados_MENU2.Name = "btn_GestionEmpleados_MENU2";
            this.btn_GestionEmpleados_MENU2.Size = new System.Drawing.Size(260, 28);
            this.btn_GestionEmpleados_MENU2.TabIndex = 26;
            this.btn_GestionEmpleados_MENU2.Text = "Gestions de Empleados";
            this.btn_GestionEmpleados_MENU2.UseVisualStyleBackColor = true;
            this.btn_GestionEmpleados_MENU2.Click += new System.EventHandler(this.btn_GestionEmpleados_MENU2_Click);
            // 
            // text_NombreUsuario_MENU2
            // 
            this.text_NombreUsuario_MENU2.Enabled = false;
            this.text_NombreUsuario_MENU2.Location = new System.Drawing.Point(252, 122);
            this.text_NombreUsuario_MENU2.Name = "text_NombreUsuario_MENU2";
            this.text_NombreUsuario_MENU2.Size = new System.Drawing.Size(246, 22);
            this.text_NombreUsuario_MENU2.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "Nombre De Usuario:";
            // 
            // btn_GenerarNomina_MENU1
            // 
            this.btn_GenerarNomina_MENU1.Location = new System.Drawing.Point(424, 386);
            this.btn_GenerarNomina_MENU1.Name = "btn_GenerarNomina_MENU1";
            this.btn_GenerarNomina_MENU1.Size = new System.Drawing.Size(160, 27);
            this.btn_GenerarNomina_MENU1.TabIndex = 37;
            this.btn_GenerarNomina_MENU1.Text = "Generar Nomina";
            this.btn_GenerarNomina_MENU1.UseVisualStyleBackColor = true;
            this.btn_GenerarNomina_MENU1.Click += new System.EventHandler(this.btn_GenerarNomina_MENU1_Click);
            // 
            // btn_ConceptosDedPer_MENU1
            // 
            this.btn_ConceptosDedPer_MENU1.Location = new System.Drawing.Point(41, 395);
            this.btn_ConceptosDedPer_MENU1.Name = "btn_ConceptosDedPer_MENU1";
            this.btn_ConceptosDedPer_MENU1.Size = new System.Drawing.Size(261, 27);
            this.btn_ConceptosDedPer_MENU1.TabIndex = 36;
            this.btn_ConceptosDedPer_MENU1.Text = "Conceptos Deduciones Percepciones";
            this.btn_ConceptosDedPer_MENU1.UseVisualStyleBackColor = true;
            this.btn_ConceptosDedPer_MENU1.Click += new System.EventHandler(this.btn_ConceptosDedPer_MENU1_Click);
            // 
            // btn_ReporteHeadcounter_MENU1
            // 
            this.btn_ReporteHeadcounter_MENU1.Location = new System.Drawing.Point(424, 179);
            this.btn_ReporteHeadcounter_MENU1.Name = "btn_ReporteHeadcounter_MENU1";
            this.btn_ReporteHeadcounter_MENU1.Size = new System.Drawing.Size(221, 25);
            this.btn_ReporteHeadcounter_MENU1.TabIndex = 34;
            this.btn_ReporteHeadcounter_MENU1.Text = "Reporte Headcounter";
            this.btn_ReporteHeadcounter_MENU1.UseVisualStyleBackColor = true;
            this.btn_ReporteHeadcounter_MENU1.Click += new System.EventHandler(this.btn_ReporteHeadcounter_MENU1_Click);
            // 
            // btn_ReporteGenNomina_MENU1
            // 
            this.btn_ReporteGenNomina_MENU1.Location = new System.Drawing.Point(424, 232);
            this.btn_ReporteGenNomina_MENU1.Name = "btn_ReporteGenNomina_MENU1";
            this.btn_ReporteGenNomina_MENU1.Size = new System.Drawing.Size(230, 26);
            this.btn_ReporteGenNomina_MENU1.TabIndex = 33;
            this.btn_ReporteGenNomina_MENU1.Text = "Reporte General de Nomina";
            this.btn_ReporteGenNomina_MENU1.UseVisualStyleBackColor = true;
            this.btn_ReporteGenNomina_MENU1.Click += new System.EventHandler(this.btn_ReporteGenNomina_MENU1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(200, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 42);
            this.label1.TabIndex = 38;
            this.label1.Text = "DSB Topografia";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_GestionPuestos_MENU2
            // 
            this.btn_GestionPuestos_MENU2.Location = new System.Drawing.Point(41, 306);
            this.btn_GestionPuestos_MENU2.Name = "btn_GestionPuestos_MENU2";
            this.btn_GestionPuestos_MENU2.Size = new System.Drawing.Size(239, 30);
            this.btn_GestionPuestos_MENU2.TabIndex = 40;
            this.btn_GestionPuestos_MENU2.Text = "Gestion de Puestos";
            this.btn_GestionPuestos_MENU2.UseVisualStyleBackColor = true;
            this.btn_GestionPuestos_MENU2.Click += new System.EventHandler(this.btn_GestionPuestos_MENU2_Click);
            // 
            // btn_GestionDepar_MENU2
            // 
            this.btn_GestionDepar_MENU2.Location = new System.Drawing.Point(41, 245);
            this.btn_GestionDepar_MENU2.Name = "btn_GestionDepar_MENU2";
            this.btn_GestionDepar_MENU2.Size = new System.Drawing.Size(235, 31);
            this.btn_GestionDepar_MENU2.TabIndex = 39;
            this.btn_GestionDepar_MENU2.Text = "Gestion de Departamento";
            this.btn_GestionDepar_MENU2.UseVisualStyleBackColor = true;
            this.btn_GestionDepar_MENU2.Click += new System.EventHandler(this.btn_GestionDepar_MENU2_Click);
            // 
            // P_Menu2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 553);
            this.ControlBox = false;
            this.Controls.Add(this.btn_GestionPuestos_MENU2);
            this.Controls.Add(this.btn_GestionDepar_MENU2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_GenerarNomina_MENU1);
            this.Controls.Add(this.btn_ConceptosDedPer_MENU1);
            this.Controls.Add(this.btn_ReporteHeadcounter_MENU1);
            this.Controls.Add(this.btn_ReporteGenNomina_MENU1);
            this.Controls.Add(this.checkBox_Admin_MENU2);
            this.Controls.Add(this.btn_Salir_MENU2);
            this.Controls.Add(this.btn_ReciboEmpleado_MENU2);
            this.Controls.Add(this.btn_GestionEmpleados_MENU2);
            this.Controls.Add(this.text_NombreUsuario_MENU2);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "P_Menu2";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.P_Menu2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox_Admin_MENU2;
        private System.Windows.Forms.Button btn_Salir_MENU2;
        private System.Windows.Forms.Button btn_ReciboEmpleado_MENU2;
        private System.Windows.Forms.Button btn_GestionEmpleados_MENU2;
        private System.Windows.Forms.TextBox text_NombreUsuario_MENU2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_GenerarNomina_MENU1;
        private System.Windows.Forms.Button btn_ConceptosDedPer_MENU1;
        private System.Windows.Forms.Button btn_ReporteHeadcounter_MENU1;
        private System.Windows.Forms.Button btn_ReporteGenNomina_MENU1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_GestionPuestos_MENU2;
        private System.Windows.Forms.Button btn_GestionDepar_MENU2;
    }
}